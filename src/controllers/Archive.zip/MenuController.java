package controllers;

import fp_ui.Connector;
import fp_ui.Username;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import controllers.LoginController;

public class MenuController{

    @FXML
    private Button btnTransaction;
    @FXML
    private Button btnTransDetail;
    @FXML
    private Button btnProduct;
    @FXML
    private Button btnCustomer;
    @FXML
    private Button btnStaff;
    @FXML
    private Button btnSupplier;
    @FXML
    private Button btnSupplierProduct;

    private Connector db;
    private Connection conn1 = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;
//
//    static String transaction(String username){
//        return username;
//    }

    @FXML
    public void transactionButtonAction(MouseEvent event) throws SQLException{
        try {
            String user = LoginController.usernameSave;
            if (username.equals("1") || username.equals("2")) {
                //add you loading or delays - ;-)
                Node node = (Node) MouseEvent.event.getSource();
                Stage stage = (Stage) node.getScene().getWindow();
                //stage.setMaximized(true);
                stage.close();
                Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/fp_ui/Transaction.fxml")));
                stage.setScene(scene);
                stage.show();
            }

        } catch (SQLException e) {
            System.out.println(e);

        } finally {
            staffName.clear();
            gender.clear();
            address.clear();
            telephone.clear();
            preparedStatement.execute();
            preparedStatement.close();
            refresh();
        }
    }
}
